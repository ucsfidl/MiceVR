function optoLoc = getOptoLoc(trialRecs, trialIdx)
% Helper function used by a lot of other functions

optoLoc = trialRecs{17}(trialIdx);

end