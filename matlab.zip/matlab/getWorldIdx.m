function worldIdx = getWorldIdx(trialRecs, trialIdx)
% Helper function used by a lot of other functions

worldIdx = trialRecs{16}(trialIdx);

end