function ext = getExtinction(trialRecs, trialIdx)

ext = trialRecs{22}(trialIdx);

end