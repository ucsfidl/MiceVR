# xml2struct

xml2struct2 takes either a java xml object, an xml file, or a string in
xml format as input and returns a parsed xml tree in structure. 

Please note that the following characters are substituted
'-' by '_dash_', ':' by '_colon_' and '.' by '_dot_'

Originally written by W. Falkena, ASTI, TUDelft, 21-08-2010
Attribute parsing speed increase by 40% by A. Wanner, 14-6-2011
Added CDATA support by I. Smirnov, 20-3-2012
Modified by X. Mo, University of Wisconsin, 12-5-2012
Modified by Chao-Yuan Yeh, August 2016

