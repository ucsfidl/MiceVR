function actionIdx = getActionIdx(trialRecs, trialIdx)
% Helper function used by lots of code

actionIdx = trialRecs{24}(trialIdx);

end