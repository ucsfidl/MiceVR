function D = getDfromA(area)

D = sqrt(area / 3.14) * 2;

end