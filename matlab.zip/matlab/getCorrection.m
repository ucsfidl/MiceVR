function corr = getCorrection(trialRecs, trialIdx)

corr = trialRecs{21}(trialIdx);

end