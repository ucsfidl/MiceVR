function stimIdx = getStimIdx(trialRecs, trialIdx)
% Helper function used by lots of code

stimIdx = trialRecs{23}(trialIdx);

end