function str = getReplayLineFormat()
% Helper to consolidate formatting changes in the actions file in one place

str = '%f %f %f %f %f %f %f %f';

end